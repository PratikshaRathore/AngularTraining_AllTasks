
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent 
{
 
  public userObj1:any = {Sno:1,ename:"Scott", pgrade: "Outstanding"};
  public userObj2:any = {Sno:2,ename:"SMITH", pgrade: "Good"};
  public userObj3:any = {Sno:3,ename:"JAMES", pgrade: "Average"};
  public userObj4:any={Sno:4,ename:"ABRONS",pgrade:"Excellent"};
  public userObj5:any={Sno:4,ename:"ADAM",pgrade:"good"};
  

  public empsArray:any[]  =
  [
    {Sno:1,ename  :  "Scott",  pgrade:  1},
    {Sno:2,ename  :  "SMITH",  pgrade:  2},
    {Sno:3,ename  :  "JAMES",  pgrade:  3},
    {Sno:4,ename  :  "ABRONS",  pgrade:  4},
    {Sno:5,ename  :  "ADAM",  pgrade:  5},
    
  ];


}