import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-employe',
  templateUrl: './employe.component.html',
  styleUrls: ['./employe.component.css']
})
export class EmployeComponent implements OnInit {



 empid: number  = 0;
 ename  :string  = "";
 emploc  :string  = "";
 isDisabled :boolean = false;

  public empsArray:Emp[] = [];


  constructor(private dataService:DataService) { }

  ngOnInit(): void {
  }


  getEmps_click()
  {
    this.empsArray  = this.dataService.getData();
  }

  addEmp_click()
  {
    let empObj:Emp = new Emp();
    empObj.empid = this.empid;
   empObj.ename = this.ename;
    empObj.emploc = this.emploc;

    this.dataService.addData(empObj);  // Insert into database
    this.empsArray  = this.dataService.getData();  // Get the latest results

    this.clearFields();
  }

  removeEmp_click(empid:number)
  {
    this.dataService.removeData(empid);
    this.empsArray  = this.dataService.getData();  // Get the latest results
  }
  selectEmp_click(empid:number)
  {
    this.dataService.selectData(empid);
		let empObj:any =  this.empsArray.find(   item =>  item.empid == this.empid   );
		this.empid =   empObj.empid;
		this.ename =   empObj.ename;
		this.emploc 		=  empObj.emploc;
    this.isDisabled = true;
  }
  updateEmp_click()
  {
    
    let index  =  this.empsArray.findIndex(   item =>  item.empid == this.empid);
    this.empsArray[index].ename = this.ename;
    this.empsArray[index].emploc = this.emploc;
    this.clearFields();

  }


  clearFields()
  {
      this.isDisabled = false;
      this.empid = 0;
      this.ename  = "";
      this.emploc  = "";
  }



}


class Emp
{
 empid  : number = 0;
  ename  : string  = "";
  emploc  : string  = "";
}
