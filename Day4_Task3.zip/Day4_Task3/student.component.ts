
import { Component, OnInit,Input,OnChanges } from '@angular/core';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent{

 
minValue:any  = '';
 maxValue:any='';


    public studentData:any[] = [
      {"sid":101,"sname":"Sriram","marks":500},
      {"sid":102,"sname":"Pratiksha","marks":700},
      {"sid":103,"sname":"Rohit","marks":520},
      {"sid":104,"sname":"Shrishti","marks":400},
      {"sid":105,"sname":"Sapna","marks":300},
      {"sid":106,"sname":"Shweta","marks":100},

      ];

     tempArray:any[] = [];

    constructor()
    {
        this.tempArray = this.studentData;
    }


      button1_click()
      {
        let minValue:number  = 300;
        let maxValue:number  = 600;
        this.tempArray =   this.studentData.filter( item =>item[minValue] == maxValue );
      }

    }